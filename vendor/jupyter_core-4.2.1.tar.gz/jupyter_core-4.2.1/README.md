# Jupyter Core

Core common functionality of Jupyter projects.

This package contains base application classes and configuration inherited by other projects.
It doesn't do much on its own.

