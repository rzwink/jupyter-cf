import warnings
warnings.warn("qtconsole.rich_ipython_widget is deprecated. use qtconsole.rich_jupyter_widget", DeprecationWarning)
from .rich_jupyter_widget import *
