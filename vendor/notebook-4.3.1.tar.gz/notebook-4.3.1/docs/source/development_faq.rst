.. _development_faq:

Developer FAQ
=============

1. How do I install a pre-release version such as a beta or release candidate?

   ``python -m pip install notebook --pre --upgrade``
