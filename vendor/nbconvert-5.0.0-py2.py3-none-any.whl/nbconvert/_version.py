version_info = (5, 0, 0)
__version__ = '.'.join(map(str, version_info[0:3])) + ''.join(version_info[3:])
